from django.contrib import admin
from .models import Gallery, Slide, Image

admin.site.register(Gallery)
admin.site.register(Slide)
admin.site.register(Image)
