A django app for displaying images in a gallery
